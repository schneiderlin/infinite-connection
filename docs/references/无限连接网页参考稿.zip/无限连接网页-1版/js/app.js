/* ====================================================
   无限连接 - 全局交互
   ==================================================== */

// 导航栏高亮当前页
(function highlightNav() {
    const path = location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-menu a').forEach(a => {
        const href = a.getAttribute('href');
        if (href === path || (path === '' && href === 'index.html')) {
            a.classList.add('active');
        }
    });
})();

// 个性化切换按钮交互
(function bindSwitches() {
    document.querySelectorAll('.switch').forEach(sw => {
        sw.querySelectorAll('button').forEach(b => {
            b.addEventListener('click', () => {
                sw.querySelectorAll('button').forEach(x => x.classList.remove('active'));
                b.classList.add('active');
            });
        });
    });
})();

// 筛选条筛选器交互
(function bindFilters() {
    document.querySelectorAll('.filter-group').forEach(g => {
        g.querySelectorAll('.filter-chip').forEach(c => {
            c.addEventListener('click', () => {
                g.querySelectorAll('.filter-chip').forEach(x => x.classList.remove('active'));
                c.classList.add('active');
            });
        });
    });
})();

// 标签分类栏交互
(function bindCatTabs() {
    document.querySelectorAll('.cat-tabs').forEach(t => {
        t.querySelectorAll('.cat-tab').forEach(c => {
            c.addEventListener('click', () => {
                t.querySelectorAll('.cat-tab').forEach(x => x.classList.remove('active'));
                c.classList.add('active');
            });
        });
    });
})();

// 排序切换
(function bindSortOpts() {
    document.querySelectorAll('.sort-opts').forEach(g => {
        g.querySelectorAll('.sort-opt').forEach(c => {
            c.addEventListener('click', () => {
                g.querySelectorAll('.sort-opt').forEach(x => x.classList.remove('active'));
                c.classList.add('active');
            });
        });
    });
})();

// 滚动至顶部悬浮按钮
(function fabTop() {
    const fabTop = document.querySelector('[data-fab="top"]');
    if (!fabTop) return;
    fabTop.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
})();

// 提示：仅展示用途的轻量文案
console.log('%c无限连接 · 公益行业资源聚合平台', 'color:#0F7B5C;font-weight:bold;font-size:14px;');
console.log('%c本页面为静态展示原型，不含真实业务功能。', 'color:#6B7280;font-size:12px;');